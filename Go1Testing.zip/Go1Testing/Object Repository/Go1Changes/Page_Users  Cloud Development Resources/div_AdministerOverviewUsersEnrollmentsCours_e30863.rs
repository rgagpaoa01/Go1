<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_AdministerOverviewUsersEnrollmentsCours_e30863</name>
   <tag></tag>
   <elementGuidId>4fca8b88-a304-4e88-9409-e9ba39586877</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.page-admin</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='box-inner']/div/admin-nav/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>29f8cbe9-0296-4327-a164-4352ac3eef90</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>page-admin</value>
      <webElementGuid>2190c8f5-0f39-4484-82ec-84522b446ee1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>AdministerOverviewUsersEnrollmentsCoursesAwardsEventsLearning ItemsGroupsUsersCreate... Import... 

.sk-spinner-three-bounce3111.sk-spinner3111 {
  margin: 0 auto;
  width: 70px;
  text-align: center; }
.sk-spinner-three-bounce3111 div {
  width: 20px;
  height: 20px;
  background-color: #333;
  border-radius: 100%;
  display: inline-block;
  -webkit-animation: sk-threeBounceDelay 1.4s infinite ease-in-out;
          animation: sk-threeBounceDelay 1.4s infinite ease-in-out;
  /* Prevent first frame from flickering when animation starts */
  -webkit-animation-fill-mode: both;
          animation-fill-mode: both; }
.sk-spinner-three-bounce3111 .sk-bounce13111 {
  -webkit-animation-delay: -0.32s;
          animation-delay: -0.32s; }
.sk-spinner-three-bounce3111 .sk-bounce23111 {
  -webkit-animation-delay: -0.16s;
          animation-delay: -0.16s; }

@-webkit-keyframes sk-threeBounceDelay {
  0%, 80%, 100% {
    -webkit-transform: scale(0);
            transform: scale(0); }

  40% {
    -webkit-transform: scale(1);
            transform: scale(1); } }

@keyframes sk-threeBounceDelay {
  0%, 80%, 100% {
    -webkit-transform: scale(0);
            transform: scale(0); }

  40% {
    -webkit-transform: scale(1);
            transform: scale(1); } }



  
  
  

Showing: *User management  Filter 1 Config Save As.grid1684585474214 {
      /* Styles for the grid */
    }

    .grid1684585474214 .ui-grid-row, .grid1684585474214 .ui-grid-cell, .grid1684585474214 .ui-grid-cell .ui-grid-vertical-bar {
      height: 55px;
    }

    .grid1684585474214 .ui-grid-row:last-child .ui-grid-cell {
      border-bottom-width: 0px;
    }

    
    

    /*
    .ui-grid[dir=rtl] .ui-grid-viewport {
      padding-left: px;
    }
    */

    
 .grid1684585474214 .ui-grid-coluiGrid-00O2 { min-width: 326px; max-width: 326px; } .grid1684585474214 .ui-grid-coluiGrid-00O5 { min-width: 130px; max-width: 130px; } .grid1684585474214 .ui-grid-coluiGrid-00O6 { min-width: 85px; max-width: 85px; } .grid1684585474214 .ui-grid-coluiGrid-00O7 { min-width: 102px; max-width: 102px; } .grid1684585474214 .ui-grid-coluiGrid-00O8 { min-width: 119px; max-width: 119px; } .grid1684585474214 .ui-grid-coluiGrid-00OB { min-width: 145px; max-width: 145px; } .grid1684585474214 .ui-grid-coluiGrid-00NX { min-width: 35px; max-width: 35px; } .grid1684585474214 .ui-grid-coluiGrid-00O1 { min-width: 198px; max-width: 198px; }
 .grid1684585474214 .ui-grid-coluiGrid-00O2 { min-width: 326px; max-width: 326px; } .grid1684585474214 .ui-grid-coluiGrid-00O5 { min-width: 130px; max-width: 130px; } .grid1684585474214 .ui-grid-coluiGrid-00O6 { min-width: 85px; max-width: 85px; } .grid1684585474214 .ui-grid-coluiGrid-00O7 { min-width: 102px; max-width: 102px; } .grid1684585474214 .ui-grid-coluiGrid-00O8 { min-width: 119px; max-width: 119px; } .grid1684585474214 .ui-grid-coluiGrid-00OB { min-width: 145px; max-width: 145px; } .grid1684585474214 .ui-grid-coluiGrid-00NX { min-width: 35px; max-width: 35px; } .grid1684585474214 .ui-grid-coluiGrid-00O1 { min-width: 198px; max-width: 198px; }

 .grid1684585474214 .ui-grid-render-container-body .ui-grid-canvas { width: 907px; height: 110px; }
 .grid1684585474214 .ui-grid-render-container-body .ui-grid-header-canvas { width: 907px; }
 .grid1684585474214 .ui-grid-render-container-body .ui-grid-header-canvas { height: inherit; }
 .grid1684585474214 .ui-grid-render-container-body .ui-grid-viewport { width: 907px; height: 50px; }
 .grid1684585474214 .ui-grid-render-container-body .ui-grid-header-viewport { width: 907px; }
 .grid1684585474214 .ui-grid-render-container-body .ui-grid-footer-canvas { width: 907px; }
 .grid1684585474214 .ui-grid-render-container-body .ui-grid-footer-viewport { width: 907px; }

 .grid1684585474214 .ui-grid-render-container-left .ui-grid-canvas { width: 233px; height: 110px; }
 .grid1684585474214 .ui-grid-render-container-left .ui-grid-header-canvas { width: 233px; }
 .grid1684585474214 .ui-grid-render-container-left .ui-grid-header-canvas { height: inherit; }
 .grid1684585474214 .ui-grid-render-container-left .ui-grid-viewport { width: 233px; height: 33px; }
 .grid1684585474214 .ui-grid-render-container-left .ui-grid-header-viewport { width: 233px; }
 .grid1684585474214 .ui-grid-render-container-left .ui-grid-footer-canvas { width: 233px; }
 .grid1684585474214 .ui-grid-render-container-left .ui-grid-footer-viewport { width: 233px; }
.grid1684585474214 .ui-grid-footer-aggregates-row { height: 30px; } .grid1684585474214 .ui-grid-footer-info { height: 30px; }
 .grid1684585474214 .ui-grid-coluiGrid-00O2 { min-width: 326px; max-width: 326px; } .grid1684585474214 .ui-grid-coluiGrid-00O5 { min-width: 130px; max-width: 130px; } .grid1684585474214 .ui-grid-coluiGrid-00O6 { min-width: 85px; max-width: 85px; } .grid1684585474214 .ui-grid-coluiGrid-00O7 { min-width: 102px; max-width: 102px; } .grid1684585474214 .ui-grid-coluiGrid-00O8 { min-width: 119px; max-width: 119px; } .grid1684585474214 .ui-grid-coluiGrid-00OB { min-width: 145px; max-width: 145px; }
.grid1684585474214 .ui-grid-pinned-container-left, .grid1684585474214 .ui-grid-pinned-container-left .ui-grid-render-container-left .ui-grid-viewport { width: 233px; } 
 .grid1684585474214 .ui-grid-coluiGrid-00NX { min-width: 35px; max-width: 35px; } .grid1684585474214 .ui-grid-coluiGrid-00O1 { min-width: 198px; max-width: 198px; } Sort Ascending Sort Descending Hide ColumnName Mavic Aquino  Split button!EditSend password resetMavic AquinoMavic Aquino  Split button!EditSend password resetMavic Aquino Sort Ascending Sort Descending Hide ColumnEmail  Hide ColumnRoles  Sort Ascending Sort Descending Hide ColumnStatus  Sort Ascending Sort Descending Hide ColumnCreated  Sort Ascending Sort Descending Hide ColumnLast Access  Hide ColumnManager Emails 9951620622@clouddevelopmentresources.mygo1.comLearnerActive05-Jul-202203-Mar-2023mavic.aquino@emids.comLearner, ManagerActive20-May-2023.grid1684585474214 .ui-grid-menu-mid { max-height: 0px; }No data available in the table   / 5  1 - 10 of 2 itemsShowing 2 10202550100  results

1


</value>
      <webElementGuid>180853ac-7e46-4a67-8e0a-475c6dbff3b6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;box-inner&quot;)/div[@class=&quot;app-uiview&quot;]/admin-nav[1]/div[@class=&quot;page-admin&quot;]</value>
      <webElementGuid>42ec5675-136a-442a-97e2-294ee1b0aa21</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='box-inner']/div/admin-nav/div</value>
      <webElementGuid>b06f0263-35b3-4843-80ef-3e7ff0bfa73f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='RA'])[2]/following::div[7]</value>
      <webElementGuid>7b9780a2-9e95-482e-a6fb-39f34cd9526e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='My teaching'])[1]/following::div[11]</value>
      <webElementGuid>1b9127d8-c85b-434f-839b-9a9e1ba8e5ce</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//admin-nav/div</value>
      <webElementGuid>d4109962-aa4a-43ca-900c-1e0aaeca18f9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'AdministerOverviewUsersEnrollmentsCoursesAwardsEventsLearning ItemsGroupsUsersCreate... Import... 

.sk-spinner-three-bounce3111.sk-spinner3111 {
  margin: 0 auto;
  width: 70px;
  text-align: center; }
.sk-spinner-three-bounce3111 div {
  width: 20px;
  height: 20px;
  background-color: #333;
  border-radius: 100%;
  display: inline-block;
  -webkit-animation: sk-threeBounceDelay 1.4s infinite ease-in-out;
          animation: sk-threeBounceDelay 1.4s infinite ease-in-out;
  /* Prevent first frame from flickering when animation starts */
  -webkit-animation-fill-mode: both;
          animation-fill-mode: both; }
.sk-spinner-three-bounce3111 .sk-bounce13111 {
  -webkit-animation-delay: -0.32s;
          animation-delay: -0.32s; }
.sk-spinner-three-bounce3111 .sk-bounce23111 {
  -webkit-animation-delay: -0.16s;
          animation-delay: -0.16s; }

@-webkit-keyframes sk-threeBounceDelay {
  0%, 80%, 100% {
    -webkit-transform: scale(0);
            transform: scale(0); }

  40% {
    -webkit-transform: scale(1);
            transform: scale(1); } }

@keyframes sk-threeBounceDelay {
  0%, 80%, 100% {
    -webkit-transform: scale(0);
            transform: scale(0); }

  40% {
    -webkit-transform: scale(1);
            transform: scale(1); } }



  
  
  

Showing: *User management  Filter 1 Config Save As.grid1684585474214 {
      /* Styles for the grid */
    }

    .grid1684585474214 .ui-grid-row, .grid1684585474214 .ui-grid-cell, .grid1684585474214 .ui-grid-cell .ui-grid-vertical-bar {
      height: 55px;
    }

    .grid1684585474214 .ui-grid-row:last-child .ui-grid-cell {
      border-bottom-width: 0px;
    }

    
    

    /*
    .ui-grid[dir=rtl] .ui-grid-viewport {
      padding-left: px;
    }
    */

    
 .grid1684585474214 .ui-grid-coluiGrid-00O2 { min-width: 326px; max-width: 326px; } .grid1684585474214 .ui-grid-coluiGrid-00O5 { min-width: 130px; max-width: 130px; } .grid1684585474214 .ui-grid-coluiGrid-00O6 { min-width: 85px; max-width: 85px; } .grid1684585474214 .ui-grid-coluiGrid-00O7 { min-width: 102px; max-width: 102px; } .grid1684585474214 .ui-grid-coluiGrid-00O8 { min-width: 119px; max-width: 119px; } .grid1684585474214 .ui-grid-coluiGrid-00OB { min-width: 145px; max-width: 145px; } .grid1684585474214 .ui-grid-coluiGrid-00NX { min-width: 35px; max-width: 35px; } .grid1684585474214 .ui-grid-coluiGrid-00O1 { min-width: 198px; max-width: 198px; }
 .grid1684585474214 .ui-grid-coluiGrid-00O2 { min-width: 326px; max-width: 326px; } .grid1684585474214 .ui-grid-coluiGrid-00O5 { min-width: 130px; max-width: 130px; } .grid1684585474214 .ui-grid-coluiGrid-00O6 { min-width: 85px; max-width: 85px; } .grid1684585474214 .ui-grid-coluiGrid-00O7 { min-width: 102px; max-width: 102px; } .grid1684585474214 .ui-grid-coluiGrid-00O8 { min-width: 119px; max-width: 119px; } .grid1684585474214 .ui-grid-coluiGrid-00OB { min-width: 145px; max-width: 145px; } .grid1684585474214 .ui-grid-coluiGrid-00NX { min-width: 35px; max-width: 35px; } .grid1684585474214 .ui-grid-coluiGrid-00O1 { min-width: 198px; max-width: 198px; }

 .grid1684585474214 .ui-grid-render-container-body .ui-grid-canvas { width: 907px; height: 110px; }
 .grid1684585474214 .ui-grid-render-container-body .ui-grid-header-canvas { width: 907px; }
 .grid1684585474214 .ui-grid-render-container-body .ui-grid-header-canvas { height: inherit; }
 .grid1684585474214 .ui-grid-render-container-body .ui-grid-viewport { width: 907px; height: 50px; }
 .grid1684585474214 .ui-grid-render-container-body .ui-grid-header-viewport { width: 907px; }
 .grid1684585474214 .ui-grid-render-container-body .ui-grid-footer-canvas { width: 907px; }
 .grid1684585474214 .ui-grid-render-container-body .ui-grid-footer-viewport { width: 907px; }

 .grid1684585474214 .ui-grid-render-container-left .ui-grid-canvas { width: 233px; height: 110px; }
 .grid1684585474214 .ui-grid-render-container-left .ui-grid-header-canvas { width: 233px; }
 .grid1684585474214 .ui-grid-render-container-left .ui-grid-header-canvas { height: inherit; }
 .grid1684585474214 .ui-grid-render-container-left .ui-grid-viewport { width: 233px; height: 33px; }
 .grid1684585474214 .ui-grid-render-container-left .ui-grid-header-viewport { width: 233px; }
 .grid1684585474214 .ui-grid-render-container-left .ui-grid-footer-canvas { width: 233px; }
 .grid1684585474214 .ui-grid-render-container-left .ui-grid-footer-viewport { width: 233px; }
.grid1684585474214 .ui-grid-footer-aggregates-row { height: 30px; } .grid1684585474214 .ui-grid-footer-info { height: 30px; }
 .grid1684585474214 .ui-grid-coluiGrid-00O2 { min-width: 326px; max-width: 326px; } .grid1684585474214 .ui-grid-coluiGrid-00O5 { min-width: 130px; max-width: 130px; } .grid1684585474214 .ui-grid-coluiGrid-00O6 { min-width: 85px; max-width: 85px; } .grid1684585474214 .ui-grid-coluiGrid-00O7 { min-width: 102px; max-width: 102px; } .grid1684585474214 .ui-grid-coluiGrid-00O8 { min-width: 119px; max-width: 119px; } .grid1684585474214 .ui-grid-coluiGrid-00OB { min-width: 145px; max-width: 145px; }
.grid1684585474214 .ui-grid-pinned-container-left, .grid1684585474214 .ui-grid-pinned-container-left .ui-grid-render-container-left .ui-grid-viewport { width: 233px; } 
 .grid1684585474214 .ui-grid-coluiGrid-00NX { min-width: 35px; max-width: 35px; } .grid1684585474214 .ui-grid-coluiGrid-00O1 { min-width: 198px; max-width: 198px; } Sort Ascending Sort Descending Hide ColumnName Mavic Aquino  Split button!EditSend password resetMavic AquinoMavic Aquino  Split button!EditSend password resetMavic Aquino Sort Ascending Sort Descending Hide ColumnEmail  Hide ColumnRoles  Sort Ascending Sort Descending Hide ColumnStatus  Sort Ascending Sort Descending Hide ColumnCreated  Sort Ascending Sort Descending Hide ColumnLast Access  Hide ColumnManager Emails 9951620622@clouddevelopmentresources.mygo1.comLearnerActive05-Jul-202203-Mar-2023mavic.aquino@emids.comLearner, ManagerActive20-May-2023.grid1684585474214 .ui-grid-menu-mid { max-height: 0px; }No data available in the table   / 5  1 - 10 of 2 itemsShowing 2 10202550100  results

1


' or . = 'AdministerOverviewUsersEnrollmentsCoursesAwardsEventsLearning ItemsGroupsUsersCreate... Import... 

.sk-spinner-three-bounce3111.sk-spinner3111 {
  margin: 0 auto;
  width: 70px;
  text-align: center; }
.sk-spinner-three-bounce3111 div {
  width: 20px;
  height: 20px;
  background-color: #333;
  border-radius: 100%;
  display: inline-block;
  -webkit-animation: sk-threeBounceDelay 1.4s infinite ease-in-out;
          animation: sk-threeBounceDelay 1.4s infinite ease-in-out;
  /* Prevent first frame from flickering when animation starts */
  -webkit-animation-fill-mode: both;
          animation-fill-mode: both; }
.sk-spinner-three-bounce3111 .sk-bounce13111 {
  -webkit-animation-delay: -0.32s;
          animation-delay: -0.32s; }
.sk-spinner-three-bounce3111 .sk-bounce23111 {
  -webkit-animation-delay: -0.16s;
          animation-delay: -0.16s; }

@-webkit-keyframes sk-threeBounceDelay {
  0%, 80%, 100% {
    -webkit-transform: scale(0);
            transform: scale(0); }

  40% {
    -webkit-transform: scale(1);
            transform: scale(1); } }

@keyframes sk-threeBounceDelay {
  0%, 80%, 100% {
    -webkit-transform: scale(0);
            transform: scale(0); }

  40% {
    -webkit-transform: scale(1);
            transform: scale(1); } }



  
  
  

Showing: *User management  Filter 1 Config Save As.grid1684585474214 {
      /* Styles for the grid */
    }

    .grid1684585474214 .ui-grid-row, .grid1684585474214 .ui-grid-cell, .grid1684585474214 .ui-grid-cell .ui-grid-vertical-bar {
      height: 55px;
    }

    .grid1684585474214 .ui-grid-row:last-child .ui-grid-cell {
      border-bottom-width: 0px;
    }

    
    

    /*
    .ui-grid[dir=rtl] .ui-grid-viewport {
      padding-left: px;
    }
    */

    
 .grid1684585474214 .ui-grid-coluiGrid-00O2 { min-width: 326px; max-width: 326px; } .grid1684585474214 .ui-grid-coluiGrid-00O5 { min-width: 130px; max-width: 130px; } .grid1684585474214 .ui-grid-coluiGrid-00O6 { min-width: 85px; max-width: 85px; } .grid1684585474214 .ui-grid-coluiGrid-00O7 { min-width: 102px; max-width: 102px; } .grid1684585474214 .ui-grid-coluiGrid-00O8 { min-width: 119px; max-width: 119px; } .grid1684585474214 .ui-grid-coluiGrid-00OB { min-width: 145px; max-width: 145px; } .grid1684585474214 .ui-grid-coluiGrid-00NX { min-width: 35px; max-width: 35px; } .grid1684585474214 .ui-grid-coluiGrid-00O1 { min-width: 198px; max-width: 198px; }
 .grid1684585474214 .ui-grid-coluiGrid-00O2 { min-width: 326px; max-width: 326px; } .grid1684585474214 .ui-grid-coluiGrid-00O5 { min-width: 130px; max-width: 130px; } .grid1684585474214 .ui-grid-coluiGrid-00O6 { min-width: 85px; max-width: 85px; } .grid1684585474214 .ui-grid-coluiGrid-00O7 { min-width: 102px; max-width: 102px; } .grid1684585474214 .ui-grid-coluiGrid-00O8 { min-width: 119px; max-width: 119px; } .grid1684585474214 .ui-grid-coluiGrid-00OB { min-width: 145px; max-width: 145px; } .grid1684585474214 .ui-grid-coluiGrid-00NX { min-width: 35px; max-width: 35px; } .grid1684585474214 .ui-grid-coluiGrid-00O1 { min-width: 198px; max-width: 198px; }

 .grid1684585474214 .ui-grid-render-container-body .ui-grid-canvas { width: 907px; height: 110px; }
 .grid1684585474214 .ui-grid-render-container-body .ui-grid-header-canvas { width: 907px; }
 .grid1684585474214 .ui-grid-render-container-body .ui-grid-header-canvas { height: inherit; }
 .grid1684585474214 .ui-grid-render-container-body .ui-grid-viewport { width: 907px; height: 50px; }
 .grid1684585474214 .ui-grid-render-container-body .ui-grid-header-viewport { width: 907px; }
 .grid1684585474214 .ui-grid-render-container-body .ui-grid-footer-canvas { width: 907px; }
 .grid1684585474214 .ui-grid-render-container-body .ui-grid-footer-viewport { width: 907px; }

 .grid1684585474214 .ui-grid-render-container-left .ui-grid-canvas { width: 233px; height: 110px; }
 .grid1684585474214 .ui-grid-render-container-left .ui-grid-header-canvas { width: 233px; }
 .grid1684585474214 .ui-grid-render-container-left .ui-grid-header-canvas { height: inherit; }
 .grid1684585474214 .ui-grid-render-container-left .ui-grid-viewport { width: 233px; height: 33px; }
 .grid1684585474214 .ui-grid-render-container-left .ui-grid-header-viewport { width: 233px; }
 .grid1684585474214 .ui-grid-render-container-left .ui-grid-footer-canvas { width: 233px; }
 .grid1684585474214 .ui-grid-render-container-left .ui-grid-footer-viewport { width: 233px; }
.grid1684585474214 .ui-grid-footer-aggregates-row { height: 30px; } .grid1684585474214 .ui-grid-footer-info { height: 30px; }
 .grid1684585474214 .ui-grid-coluiGrid-00O2 { min-width: 326px; max-width: 326px; } .grid1684585474214 .ui-grid-coluiGrid-00O5 { min-width: 130px; max-width: 130px; } .grid1684585474214 .ui-grid-coluiGrid-00O6 { min-width: 85px; max-width: 85px; } .grid1684585474214 .ui-grid-coluiGrid-00O7 { min-width: 102px; max-width: 102px; } .grid1684585474214 .ui-grid-coluiGrid-00O8 { min-width: 119px; max-width: 119px; } .grid1684585474214 .ui-grid-coluiGrid-00OB { min-width: 145px; max-width: 145px; }
.grid1684585474214 .ui-grid-pinned-container-left, .grid1684585474214 .ui-grid-pinned-container-left .ui-grid-render-container-left .ui-grid-viewport { width: 233px; } 
 .grid1684585474214 .ui-grid-coluiGrid-00NX { min-width: 35px; max-width: 35px; } .grid1684585474214 .ui-grid-coluiGrid-00O1 { min-width: 198px; max-width: 198px; } Sort Ascending Sort Descending Hide ColumnName Mavic Aquino  Split button!EditSend password resetMavic AquinoMavic Aquino  Split button!EditSend password resetMavic Aquino Sort Ascending Sort Descending Hide ColumnEmail  Hide ColumnRoles  Sort Ascending Sort Descending Hide ColumnStatus  Sort Ascending Sort Descending Hide ColumnCreated  Sort Ascending Sort Descending Hide ColumnLast Access  Hide ColumnManager Emails 9951620622@clouddevelopmentresources.mygo1.comLearnerActive05-Jul-202203-Mar-2023mavic.aquino@emids.comLearner, ManagerActive20-May-2023.grid1684585474214 .ui-grid-menu-mid { max-height: 0px; }No data available in the table   / 5  1 - 10 of 2 itemsShowing 2 10202550100  results

1


')]</value>
      <webElementGuid>b9f1d6bb-2247-4804-8c14-d54174861cce</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
