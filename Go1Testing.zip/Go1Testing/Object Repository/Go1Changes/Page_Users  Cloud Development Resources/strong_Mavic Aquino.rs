<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>strong_Mavic Aquino</name>
   <tag></tag>
   <elementGuidId>8ab5b877-d3bd-4de3-99a3-2f857dc36984</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#1684585474214-1-uiGrid-00O1-cell > div.ui-grid-cell-contents > user-name-menu > div.column-name-right > div.user-name-dropdown.btn-group.bootstrap-element-nowrap.dropdown > a.btn.btn-default > strong</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='1684585474214-1-uiGrid-00O1-cell']/div/user-name-menu/div[2]/div/a/strong</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>strong</value>
      <webElementGuid>e6a13b01-2870-4b28-9a9e-7069e18dc2de</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Mavic Aquino</value>
      <webElementGuid>68276094-a5e9-4870-9cbe-4db525e9cfb7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;1684585474214-1-uiGrid-00O1-cell&quot;)/div[@class=&quot;ui-grid-cell-contents&quot;]/user-name-menu[1]/div[@class=&quot;column-name-right&quot;]/div[@class=&quot;user-name-dropdown btn-group bootstrap-element-nowrap dropdown&quot;]/a[@class=&quot;btn btn-default&quot;]/strong[1]</value>
      <webElementGuid>952a877c-d0f7-4e64-a53b-86b706be824d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='1684585474214-1-uiGrid-00O1-cell']/div/user-name-menu/div[2]/div/a/strong</value>
      <webElementGuid>3db38ed9-f8f5-4c7e-a7af-2d24357d1fd8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mavic Aquino'])[2]/following::strong[1]</value>
      <webElementGuid>79adf284-9f6c-4e51-bf9c-edf53f1f76bd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Send password reset'])[1]/following::strong[2]</value>
      <webElementGuid>b61371c9-3ba9-42e9-9a75-dcacb203dac6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Split button!'])[2]/preceding::strong[1]</value>
      <webElementGuid>7b9061f8-2039-4fb1-8040-51dfd3e1f672</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Edit'])[2]/preceding::strong[1]</value>
      <webElementGuid>893d505c-11cf-4797-946c-e5b9688052ac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div[2]/div/user-name-menu/div[2]/div/a/strong</value>
      <webElementGuid>7444f0b7-fb4b-41c4-a9e1-43d312cc3159</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//strong[(text() = 'Mavic Aquino' or . = 'Mavic Aquino')]</value>
      <webElementGuid>1ed70ea6-cb06-427f-aff7-dc5b9b6bb4d4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
