<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_In progress</name>
   <tag></tag>
   <elementGuidId>5abfaaeb-a0c6-4582-b76a-8cda255945a2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.primary-tab.primary-tab-border.active > a > span</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='box-inner']/div/my-learning/div/div/ul/li/a/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>85ab3a4d-3772-40bf-9cd2-2cb84b1168ef</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>In progress</value>
      <webElementGuid>a883511e-21cf-4855-8955-d8b2bcbbc2e0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;box-inner&quot;)/div[@class=&quot;app-uiview&quot;]/my-learning[1]/div[@class=&quot;page--banner page--banner-nav&quot;]/div[@class=&quot;container&quot;]/ul[@class=&quot;nav nav-underline nav-underline-center&quot;]/li[@class=&quot;primary-tab primary-tab-border active&quot;]/a[1]/span[1]</value>
      <webElementGuid>ad20b709-64a2-4481-8385-6d15ed5f7cec</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='box-inner']/div/my-learning/div/div/ul/li/a/span</value>
      <webElementGuid>17518dc3-9cdd-4138-a332-49774ce3c307</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='My Learning'])[1]/following::span[1]</value>
      <webElementGuid>67eb2962-b2f1-40b1-9a97-555e63bf23ed</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='RA'])[2]/following::span[2]</value>
      <webElementGuid>1cbda4be-a08e-4060-ba36-fc03655092b9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Assigned'])[1]/preceding::span[1]</value>
      <webElementGuid>33f4bbbf-ef8f-4a1d-a752-922e2ad8b4b1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Scheduled'])[1]/preceding::span[2]</value>
      <webElementGuid>2ba4aa2f-ad2d-4692-aa2a-41c6073dea4e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='In progress']/parent::*</value>
      <webElementGuid>d25000a3-fa0b-4ad4-b91f-cc4be9009e37</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li/a/span</value>
      <webElementGuid>d4f17ef8-87ee-4546-8bad-2bea4857b89c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'In progress' or . = 'In progress')]</value>
      <webElementGuid>a525198b-557c-493f-917c-1c0be4155020</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
