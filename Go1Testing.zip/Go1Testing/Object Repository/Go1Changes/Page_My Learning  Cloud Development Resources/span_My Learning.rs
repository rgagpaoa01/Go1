<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_My Learning</name>
   <tag></tag>
   <elementGuidId>6a692940-45c5-4dda-8ebe-a1e9e96a1a38</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h2.page--title > span</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='box-inner']/div/my-learning/div/div/h2/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>d14fa9a7-3744-42d7-9af1-929c3dba2d94</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>My Learning</value>
      <webElementGuid>5babd446-3b24-47f7-b805-986fba6e7594</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;box-inner&quot;)/div[@class=&quot;app-uiview&quot;]/my-learning[1]/div[@class=&quot;page--banner page--banner-nav&quot;]/div[@class=&quot;container&quot;]/h2[@class=&quot;page--title&quot;]/span[1]</value>
      <webElementGuid>2a4f70d4-18bd-4ea5-aa35-b81ad4c2ad26</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='box-inner']/div/my-learning/div/div/h2/span</value>
      <webElementGuid>ce77f2cd-07e0-4e6c-ac36-13bfcf591d46</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='RA'])[2]/following::span[1]</value>
      <webElementGuid>e6587364-f58c-48cc-aa13-fbad8a786265</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='My teaching'])[1]/following::span[3]</value>
      <webElementGuid>1cc74fda-2f7f-4816-83e7-cd1405309cd7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='In progress'])[1]/preceding::span[1]</value>
      <webElementGuid>a989a956-483a-4369-bb47-25484187e5ea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Assigned'])[1]/preceding::span[2]</value>
      <webElementGuid>b3dcac39-ddaf-4e43-8888-1685fd5c4866</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='My Learning']/parent::*</value>
      <webElementGuid>2c2cc435-36cf-477d-9943-708d28cefde2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h2/span</value>
      <webElementGuid>3118971e-576d-4ce9-b24c-56197342ad79</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'My Learning' or . = 'My Learning')]</value>
      <webElementGuid>1ed5d0df-52be-40ad-b923-c0e69f70fd09</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
